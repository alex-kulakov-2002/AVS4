#include <stdio.h>

#include "extdata.h"

double ParallelepipedVolume(void *p);
void OutParallelepiped(void *p, FILE *outputFile) {
    fprintf(outputFile, "Parallelepiped: ");
    fprintf(outputFile, "length = %d, ", *((int*)p));
    fprintf(outputFile, "width = %d, ", *((int*)(p+intSize)));
    fprintf(outputFile, "depth = %d, ", *((int*)(p+2*intSize)));
    fprintf(outputFile, "Volume = %f, ", ParallelepipedVolume(p));
}

double SphereVolume(void *s);
void OutSphere(void *s, FILE *outputFile) {
    fprintf(outputFile, "Sphere: ");
    fprintf(outputFile, "radius = %d, ", *((int*)s));
    fprintf(outputFile, "volume = %f, ", SphereVolume(s));
}

double TetrahedronVolume(void *t);
void OutTetrahedron(void *t, FILE *outputFile) {
    fprintf(outputFile, "Tetrahedron: ");
    fprintf(outputFile, "length = %d, ", *((int*)t));
    fprintf(outputFile, "volume = %f, ", TetrahedronVolume(t));
}

void OutFigure(void *f, FILE *outputFile) {
    int key = *((int*)f);
    switch(key) {
        case 1:
            OutSphere(f+2*intSize, outputFile);
            fprintf(outputFile,"Density = %d\n", *((int*)(f+intSize)));
            break;
        case 2:
            OutParallelepiped(f+2*intSize, outputFile);
            fprintf(outputFile,"Density = %d\n", *((int*)(f+intSize)));
            break;
        case 3:
            OutTetrahedron(f+2*intSize, outputFile);
            fprintf(outputFile,"Density = %d\n", *((int*)(f+intSize)));
            break;
        default:
            fprintf(outputFile,"Bad figure\n");
    }
}

void OutPut(void *c, int len, FILE *outputFile) {
    void *tmp = c;
    fprintf(outputFile, "Container contains %d elements.\n", len);
    for(int i = 0; i < len; i++) {
        fprintf(outputFile, "%d: ", i);
        OutFigure(tmp, outputFile);
        tmp = tmp + figureSize;
    }
}
