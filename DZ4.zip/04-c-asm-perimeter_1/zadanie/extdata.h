#ifndef __extdata__
#define __extdata__

int const intSize;
int const parallSize;
int const circleSize;
int const tetrahedronSize;
int const figureSize;
int const maxSize;
int const TETRAHEDRON;
int const PARALLELEPIPED;
int const SPHERE;

#endif //__extdata__
