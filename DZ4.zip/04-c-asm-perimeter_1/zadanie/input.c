#include <stdio.h>

#include "extdata.h"

void InSphere(void *s, FILE *inputFile) {
    fscanf(inputFile, "%d", (int*)s);
}

void InParallelepiped(void *p, FILE *inputFile) {
    fscanf(inputFile, "%d%d%d", (int*)p, (int*)(p+intSize), (int*)(p+2*intSize));
}

void InTetrahedron(void *t, FILE *inputFile) {
    fscanf(inputFile, "%d", (int*)t);
}

int InFigure(void *f, FILE *inputFile) {
    int key, density;
    int read = fscanf(inputFile, "%d%d", &key, &density);

    if (read != 2) {
        return 0;
    }

    *((int*)(f + intSize)) = density;
    switch(key) {
        case 1:
            *((int*)f) = SPHERE;
            InSphere(f+2*intSize, inputFile);
            return 1;
        case 2:
            *((int*)f) = PARALLELEPIPED;
            InParallelepiped(f+2*intSize, inputFile);
            return 1;
        case 3:
            *((int*)f) = TETRAHEDRON;
            InTetrahedron(f+2*intSize, inputFile);
            return 1;
        default:
            return 0;
    }
}

void InContainer(void *c, int *len, FILE *inputFile) {
    void *tmp = c;
    while(!feof(inputFile)) {
        if(InFigure(tmp, inputFile)) {
            tmp = tmp + figureSize;
            (*len)++;
        }
    }
}
