#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#include "data.h"

int main(int argc, char* argv[]) {
    unsigned char cont[maxSize];
    clock_t time_start = clock();
    int len = 0;

    if(argc != 5) {
        printf("Error");
        return 1;
    }

    printf("Start\n");

    if(!strcmp(argv[1], "-f")) {
        FILE *input = fopen(argv[2], "r");

        if(!input) {
            printf("Error");
            return 1;
        }

        InContainer(cont, &len, input);
        fclose(input);
    } else if(!strcmp(argv[1], "-n")) {
        int size = atoi(argv[2]);
        if((size < 1) || (size > 10000)) { 
            printf("Error");
            return 1;
        }

        srand((unsigned int)(time(0)));
        InRndContainer(cont, &len, size);
    } else {
        printf("Error");
        return 1;
    }

    FILE *outputFile1;
    if (!(outputFile1 = fopen(argv[3], "w+"))){
        printf("Error");
        return 1;
    }

    fprintf(outputFile1, "Filled container:\n");
    printf("Filled container: \n");
    OutPut(cont, len, outputFile1);
    OutPut(cont, len, stdout);
    fclose(outputFile1);

    FILE *outputFile2;
    if (!(outputFile2 = fopen(argv[4], "w+"))){
        printf("Error");
        return 1;
    }

    fprintf(outputFile2, "Changed container: \n");
    printf("\nChanged container: \n");
    ShapeByVolume(cont, &len);

    OutPut(cont, len, outputFile2);
    OutPut(cont, len, stdout);
    fclose(outputFile2);

    printf("Seconds: %f\n", ((double)(clock() - time_start))/ CLOCKS_PER_SEC);

    return 0;
}
