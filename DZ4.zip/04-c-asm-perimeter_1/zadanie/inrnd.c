#include <stdlib.h>

#include "extdata.h"

int Random(){
    return rand() % 40 + 1;
}

int RandomOneToThree(){
    return rand() % 3 + 1;
}

void InRndSphere(void *s) {
    int radius = Random();
    *((int*)s) = radius;
}

void InRndParallelepiped(void *p) {
    int width = Random();
    *((int*)p) = width;
    int length = Random();
    *((int*)(p+intSize)) = length;
    int depth = Random();
    *((int*)(p+2*intSize)) = depth;
}

void InRndTetrahedron(void *t) {
    int lengthOfLine = Random();
    *((int*)t) = lengthOfLine;
}

int InRndFigure(void *f) {
    int key = rand() % 3 + 1;
    int density = Random();
    *((int*)(f + intSize)) = density;
    switch(key) {
        case 1:
            *((int*)f) = SPHERE;
            InRndSphere(f+2*intSize);
            return 1;
        case 2:
            *((int*)f) = PARALLELEPIPED;
            InRndParallelepiped(f+2*intSize);
            return 1;
        case 3:
            *((int*)f) = TETRAHEDRON;
            InRndTetrahedron(f+2*intSize);
            return 1;
        default:
            return 0;
    }
}

void InRndContainer(void *c, int *len, int size) {
    void *tmp = c;
    while(*len < size) {
        if(InRndFigure(tmp)) {
            tmp = tmp + figureSize;
            (*len)++;
        }
    }
}
