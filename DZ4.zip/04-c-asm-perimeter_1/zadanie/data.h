#ifndef __data__
#define __data__

int const intSize = sizeof(int);
int const parallSize = 3 * sizeof(int);
int const circleSize = sizeof(int);
int const tetrahedronSize = sizeof(int);
int const figureSize = 5 * sizeof(int);
int const maxSize = 10000 * figureSize;
int const SPHERE = 1;
int const PARALLELEPIPED = 2;
int const TETRAHEDRON = 3;


void InContainer(void *c, int *len, FILE *inputFile);
void InRndContainer(void *c, int *len, int size);
void OutPut(void *c, int len, FILE *outputFile);
extern double ShapeByVolume(void *c, int *len);

#endif //__data__
